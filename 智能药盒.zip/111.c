/*
 * Copyright (c) 2022 FuZhou Lockzhiner Electronic Co., Ltd. All rights reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cJSON.h>
#include "ohos_init.h"
#include "LOS_task.h"
#include "oc_mqtt.h"
#include "e53_intelligent_street_lamp.h"
#include "lz_hardware.h"
#include "config_network.h"
#include "LOS_queue.h"
#include <time.h>
#include "lcd.h"  // 添加LCD头文件
#include "los_swtmr.h"//定时器头文件

#define ROUTE_SSID                      "xiaomi"
#define ROUTE_PASSWORD                  "12345678"

#define MSG_QUEUE_LENGTH                16
#define BUFFER_LEN                      50

#define CLIENT_ID                       "682b129884adf27cda5a4765_yaohe_0_0_2025051914"
#define USERNAME                        "682b129884adf27cda5a4765_yaohe"
#define PASSWORD                        "76b26508b3988e3968fe995ddf13a9f9238cf56cb47f6dbed6a88c6cdf3900d0"

// 添加缺失的类型定义
typedef struct {
    char morning_time[16];
    char noon_time[16];
    char evening_time[16];
} medicine_schedule1_t;

typedef struct
{
    int cover_status;
} isl_report_t;

typedef struct
{
    int64_t device_send_time;
    int64_t server_recv_time;
    int64_t server_send_time;
} time_sync_data_t;

typedef struct
{
    en_msg_type_t msg_type;
    cmd_t cmd;
    isl_report_t report;
    time_sync_data_t time_sync;
} isl_msg_t;

typedef struct
{
    int connected;
    int led;
    int motor;
    int device_send_time;
    int server_recv_time;
    int server_send_time;
} isl_status_t;

static unsigned int m_isl_msg_queue;
static isl_status_t m_app_status;
static medicine_schedule1_t g_medicine_schedule1 = {0}; // 移除static修饰符

// 全局变量存储时间信息
static int64_t g_current_time_ms = 0;        // 当前设备时间（毫秒级）
static int64_t g_last_remind_time_ms = 0;     // 上一次提醒时间戳
static int q_year = 0;
static int q_mon = 1;
static int q_day = 1;
static int q_hour = 0;
static int q_min = 0;
static int q_morining = 0;
static int q_noon = 0;
static int q_evening = 0;

void display_medicine_times(void);
void send_event_response_message(char *request_id, int device_send_time, int server_recv_time, int server_send_time);
void update_device_time(int64_t device_send_time, int64_t server_recv_time, int64_t server_send_time);
/***************************************************************
* 函数名称: isl_deal_report_msg
* 说    明: 上报智慧路灯模块数据到华为云上
* 参    数: report：智慧路灯上报消息指针
* 返 回 值: 无
***************************************************************/
void isl_deal_report_msg(isl_report_t *report)
{
    oc_mqtt_profile_service_t service;
    oc_mqtt_profile_kv_t cover_status;

    service.event_time = NULL;
    service.service_id = "智能药盒";
    service.service_property = &cover_status;
    service.nxt = NULL;

    cover_status.key = "cover_status";
    cover_status.value = &report->cover_status;
    cover_status.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    cover_status.nxt = NULL;

    oc_mqtt_profile_propertyreport(USERNAME, &service);
    
    // 上报服药时间属性
    oc_mqtt_profile_service_t medicine_service;
    oc_mqtt_profile_kv_t morning_kv, noon_kv, evening_kv;

    medicine_service.event_time = NULL;
    medicine_service.service_id = "SetMedicineTime";
    medicine_service.service_property = &morning_kv;

    morning_kv.key = "bin1_morning_time";
    morning_kv.value = g_medicine_schedule1.morning_time; // 直接使用数组名
    morning_kv.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    morning_kv.nxt = &noon_kv;

    noon_kv.key = "bin1_noon_time";
    noon_kv.value = g_medicine_schedule1.noon_time; // 直接使用数组名
    noon_kv.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    noon_kv.nxt = &evening_kv;

    evening_kv.key = "bin1_evening_time";
    evening_kv.value = g_medicine_schedule1.evening_time; // 直接使用数组名
    evening_kv.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
    evening_kv.nxt = NULL;

    oc_mqtt_profile_propertyreport(USERNAME, &medicine_service);
    return;
}

/***************************************************************
* 函数名称: isl_cmd_response_callback
* 说    明: 华为云命令处理回调函数
* 参    数: recv_data：接收的数据指针
*           recv_size：接收数据的大小
*           resp_data：响应数据的指针
*           resp_size：响应数据的大小
* 返 回 值: 无
***************************************************************/
void isl_cmd_response_callback(uint8_t *recv_data, size_t recv_size, const char *topic, uint8_t **resp_data, size_t *resp_size)
{
    isl_msg_t *app_msg = NULL;

    app_msg = malloc(sizeof(isl_msg_t));
    if (app_msg == NULL)
    {
        printf("malloc msg fail");
        return;
    }
    app_msg->msg_type = en_msg_cmd;
    app_msg->cmd.payload = (char *)recv_data;

    // 从主题中提取 request_id
    const char *request_id_start = strstr(topic, "request_id=");
    if (request_id_start != NULL)
    {
        request_id_start += strlen("request_id=");
        const char *request_id_end = strchr(request_id_start, '{');
        if (request_id_end == NULL)
        {
            request_id_end = request_id_start + strlen(request_id_start);
        }
        size_t request_id_len = request_id_end - request_id_start;

        // 分配内存并拷贝 request_id
        app_msg->cmd.request_id = malloc(request_id_len + 1);
        if (app_msg->cmd.request_id != NULL)
        {
            strncpy((char *)app_msg->cmd.request_id, request_id_start, request_id_len);
            app_msg->cmd.request_id[request_id_len] = '\0';
            printf("Extracted request_id: %s\n", app_msg->cmd.request_id);
        }
        else
        {
            printf("Failed to allocate memory for request_id\n");
        }
    }
    else
    {
        app_msg->cmd.request_id = NULL;
    }

    printf("recv data is %.*s", recv_size, recv_data);
    if (LOS_QueueWrite(m_isl_msg_queue, (void *)app_msg, sizeof(isl_msg_t), 0) != LOS_OK)
    {
        printf("%s LOS_QueueWrite fail\n", __func__);
        free(recv_data);
        free(app_msg);
    }
    *resp_data = NULL;
    *resp_size = 0;
}

/***************************************************************
* 函数名称: isl_deal_cmd_msg()
* 说    明: 处理华为云下发的命令
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void isl_deal_cmd_msg(cmd_t *cmd)
{
    cJSON *obj_root;
    cJSON *obj_cmdname;
    cJSON *obj_paras;
    cJSON *obj_para;
    int cmdret = 1;
    oc_mqtt_profile_cmdresp_t cmdresp;

    obj_root = cJSON_Parse(cmd->payload);
    if (obj_root == NULL)
    {
        printf("Failed to parse command payload\n");
        goto EXIT_JSONPARSE;
    }

    obj_cmdname = cJSON_GetObjectItem(obj_root, "command_name");
    if (obj_cmdname == NULL)
    {
        printf("Failed to get command_name\n");
        goto EXIT;
    }
    if (0 == strcmp(cJSON_GetStringValue(obj_cmdname), "蜂鸣器控制"))
    {
        obj_paras = cJSON_GetObjectItem(obj_root, "paras");
        if (obj_paras == NULL)
        {
            printf("Failed to get paras\n");
            goto EXIT;
        }
        obj_para = cJSON_GetObjectItem(obj_paras, "buzzer");
        if (obj_para == NULL)
        {
            printf("Failed to get buzzer status\n");
            goto EXIT;
        }
        if (0 == strcmp(cJSON_GetStringValue(obj_para), "ON"))
        {
            m_app_status.led = 1;
            printf("buzzer On\n");
        }
        else
        {
            m_app_status.led = 0;
            printf("buzzer Off\n");
        }
        cmdret = 0;
    }
    else if (0 == strcmp(cJSON_GetStringValue(obj_cmdname), "电机控制"))
    {
        obj_paras = cJSON_GetObjectItem(obj_root, "Paras");
        if (obj_paras == NULL)
        {
            printf("Failed to get Paras\n");
            goto EXIT;
        }
        obj_para = cJSON_GetObjectItem(obj_paras, "Motor");
        if (obj_para == NULL)
        {
            printf("Failed to get Motor status\n");
            goto EXIT;
        }
        if (0 == strcmp(cJSON_GetStringValue(obj_para), "ON"))
        {
            m_app_status.motor = 1;
            printf("Motor On\n");
        }
        else
        {
            m_app_status.motor = 0;
            printf("Motor Off\n");
        }
        cmdret = 0;
    }
    else if (0 == strcmp(cJSON_GetStringValue(obj_cmdname), "药盒1")) {
        obj_paras = cJSON_GetObjectItem(obj_root, "paras");
        
        if (obj_paras == NULL) {
            printf("Failed to get paras\n");
            goto EXIT;
        }

        // 解析早、中、晚时间
        cJSON *obj_morning = cJSON_GetObjectItem(obj_paras, "morning_time");
        cJSON *obj_noon = cJSON_GetObjectItem(obj_paras, "noon_time");
        cJSON *obj_evening = cJSON_GetObjectItem(obj_paras, "evening_time");

        if (obj_morning && obj_noon && obj_evening) {
            // 使用 strncpy + 手动终止
            strncpy(g_medicine_schedule1.morning_time, cJSON_GetStringValue(obj_morning), sizeof(g_medicine_schedule1.morning_time)-1);
            g_medicine_schedule1.morning_time[sizeof(g_medicine_schedule1.morning_time)-1] = '\0';
    
            strncpy(g_medicine_schedule1.noon_time, cJSON_GetStringValue(obj_noon), sizeof(g_medicine_schedule1.noon_time)-1);
            g_medicine_schedule1.noon_time[sizeof(g_medicine_schedule1.noon_time)-1] = '\0';
    
            strncpy(g_medicine_schedule1.evening_time, cJSON_GetStringValue(obj_evening), sizeof(g_medicine_schedule1.evening_time)-1);
            g_medicine_schedule1.evening_time[sizeof(g_medicine_schedule1.evening_time)-1] = '\0';

            printf("Received Medicine Time: Morning=%s, Noon=%s, Evening=%s\n", 
                   g_medicine_schedule1.morning_time, 
                   g_medicine_schedule1.noon_time, 
                   g_medicine_schedule1.evening_time);

            // 上报时间到云端
            oc_mqtt_profile_service_t service;
            oc_mqtt_profile_kv_t time_morning, time_noon, time_evening;

            service.event_time = NULL;
            service.service_id = "SetMedicineTime";
            service.service_property = &time_morning;
            service.nxt = NULL;

            time_morning.key = "bin1_morning_time";
            time_morning.value = g_medicine_schedule1.morning_time; // 直接使用数组名
            time_morning.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
            time_morning.nxt = &time_noon;

            time_noon.key = "bin1_noon_time";
            time_noon.value = g_medicine_schedule1.noon_time; // 直接使用数组名
            time_noon.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
            time_noon.nxt = &time_evening;

            time_evening.key = "bin1_evening_time";
            time_evening.value = g_medicine_schedule1.evening_time; // 直接使用数组名
            time_evening.type = EN_OC_MQTT_PROFILE_VALUE_STRING;
            time_evening.nxt = NULL;

            oc_mqtt_profile_propertyreport(USERNAME, &service);
            
            cmdret = 0;
        } else {
            printf("Invalid time parameters\n");
        }
        cmdret = 0;
    }
    // 发送响应（仅在解析成功时发送）
    if (cmdret == 0) {
        cmdresp.request_id = cmd->request_id;
        cmdresp.ret_code = cmdret;
        cmdresp.ret_name = "success";
        cmdresp.paras=NULL;
        oc_mqtt_profile_cmdresp(USERNAME, &cmdresp);
    }

    printf("Sending command response\n");
    printf("Response request_id: %s\n", cmdresp.request_id);
    printf("Response ret_code: %d\n", cmdresp.ret_code);
    // 发送响应后释放 request_id 
    if (cmd->request_id != NULL) {
        free(cmd->request_id);
        cmd->request_id = NULL;
    }
EXIT:
    cJSON_Delete(obj_root);
EXIT_JSONPARSE:
    cmdresp.paras = NULL;
    cmdresp.request_id = NULL;
    cmdresp.ret_code = 1;
    cmdresp.ret_name = NULL;
    return ;
}

/***************************************************************
* 函数名称: send_event_message()
* 说    明: 发送时间同步请求
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void send_event_message()
{
    char topic[100];
    snprintf(topic, sizeof(topic), "$oc/devices/%s/sys/events/up", USERNAME);

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "object_device_id",USERNAME);

    cJSON *services = cJSON_CreateArray();
    cJSON *service = cJSON_CreateObject();
    cJSON_AddStringToObject(service, "service_id", "$time_sync");
    cJSON_AddStringToObject(service, "event_type", "time_sync_request");
    cJSON_AddStringToObject(service, "event_time", NULL);

    cJSON *paras = cJSON_CreateObject();
    cJSON_AddNumberToObject(paras, "device_send_time", 1582685678789);
    cJSON_AddItemToObject(service, "paras", paras);

    cJSON_AddItemToArray(services, service);
    cJSON_AddItemToObject(root, "services", services);

    char *payload = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);

    oc_mqtt_publish(topic, (uint8_t *)payload, strlen(payload), 1);
    free(payload);
}

/***************************************************************
* 函数名称: isl_deal_send_event_response_message
* 说    明: 发送设备时间同步响应
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void send_event_response_message(char *request_id, int device_send_time, int server_recv_time, int server_send_time)
{
    char topic[100];
    snprintf(topic, sizeof(topic), "$oc/devices/%s/sys/events/down", USERNAME);

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "object_device_id", USERNAME);

    cJSON *services = cJSON_CreateArray();
    cJSON *service = cJSON_CreateObject();
    cJSON_AddStringToObject(service, "service_id", "$time_sync");
    cJSON_AddStringToObject(service, "event_type", "time_sync_response");
    cJSON_AddStringToObject(service, "event_time", NULL);

    cJSON *paras = cJSON_CreateObject();
    cJSON_AddNumberToObject(paras, "device_send_time", device_send_time);
    cJSON_AddNumberToObject(paras, "server_recv_time", server_recv_time);
    cJSON_AddNumberToObject(paras, "server_send_time", server_send_time);
    cJSON_AddItemToObject(service, "paras", paras);

    cJSON_AddItemToArray(services, service);
    cJSON_AddItemToObject(root, "services", services);

    char *payload = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);

    oc_mqtt_publish(topic, (uint8_t *)payload, strlen(payload), 1);
    free(payload);
 
}

/***************************************************************
* 函数名称: isl_time_sync_callback
* 说    明: 处理华为云下发的时间同步响应
* 参    数: recv_data：接收的数据指针
*           recv_size：接收数据的大小
* 返 回 值: 无
***************************************************************/
void isl_time_sync_callback(uint8_t *recv_data, size_t recv_size)
{
    printf("Entered isl_time_sync_callback\n");
    printf("Received time sync response: %.*s\n", recv_size, recv_data);

    cJSON *obj_root = cJSON_Parse((char *)recv_data);
    if (obj_root == NULL) {
        printf("Failed to parse JSON data\n");
        return;
    }

    cJSON *obj_services = cJSON_GetObjectItem(obj_root, "services");
    if (obj_services == NULL || !cJSON_IsArray(obj_services)) {
        printf("Failed to get services array\n");
        cJSON_Delete(obj_root);
        return;
    }

    cJSON *obj_service = cJSON_GetArrayItem(obj_services, 0);
    if (obj_service == NULL) {
        printf("Failed to get service item\n");
        cJSON_Delete(obj_root);
        return;
    }

    cJSON *obj_paras = cJSON_GetObjectItem(obj_service, "paras");
    if (obj_paras == NULL) {
        printf("Failed to get paras object\n");
        cJSON_Delete(obj_root);
        return;
    }

    cJSON *obj_device_send_time = cJSON_GetObjectItem(obj_paras, "device_send_time");
    cJSON *obj_server_recv_time = cJSON_GetObjectItem(obj_paras, "server_recv_time");
    cJSON *obj_server_send_time = cJSON_GetObjectItem(obj_paras, "server_send_time");

    // 检查字段是否为数值类型
    if (!cJSON_IsNumber(obj_device_send_time) || 
        !cJSON_IsNumber(obj_server_recv_time) || 
        !cJSON_IsNumber(obj_server_send_time)) {
        printf("Time fields are not numbers\n");
        cJSON_Delete(obj_root);
        return;
    }

    // 直接获取数值
    int64_t device_send_time = (int64_t)cJSON_GetNumberValue(obj_device_send_time);
    int64_t server_recv_time = (int64_t)cJSON_GetNumberValue(obj_server_recv_time);
    int64_t server_send_time = (int64_t)cJSON_GetNumberValue(obj_server_send_time);

    printf("Parsed timestamp values:\n");
    printf("device_send_time: %lld\n", device_send_time);
    printf("server_recv_time: %lld\n", server_recv_time);
    printf("server_send_time: %lld\n", server_send_time);

    // 写入消息队列
    isl_msg_t *app_msg = malloc(sizeof(isl_msg_t));
    if (app_msg != NULL) {
        app_msg->msg_type = en_msg_time_sync;
        app_msg->time_sync.device_send_time = device_send_time;
        app_msg->time_sync.server_recv_time = server_recv_time;
        app_msg->time_sync.server_send_time = server_send_time;

        if (LOS_QueueWrite(m_isl_msg_queue, (void *)app_msg, sizeof(isl_msg_t), 0) != LOS_OK) {
            free(app_msg);
        }
    }

    cJSON_Delete(obj_root);
}

/***************************************************************
* 函数名称: timestamp_to_datetime
* 说    明: 将时间戳转换成年月日
* 参    数: timestamp_ms 获取的时间
* 返 回 值: 无
***************************************************************/
void timestamp_to_datetime(int64_t timestamp_ms) {
    // 分解时间戳
    time_t total_seconds = timestamp_ms / 1000;
    uint32_t milliseconds = timestamp_ms % 1000;
    // 转换为 UTC 时间
    struct tm *time_info = localtime(&total_seconds);
    
    // 提取年月日
    int year = time_info->tm_year + 1900;
    int month = time_info->tm_mon + 1;
    int day = time_info->tm_mday;

    // 输出结果
    printf("UTC 时间: %04d-%02d-%02d %02d:%02d:%02d.%03d\n",
           year, month, day,
           time_info->tm_hour, time_info->tm_min, time_info->tm_sec,
           milliseconds);
    q_year=year;
    q_mon=month;
    q_day=day;
    q_hour=time_info->tm_hour;
    q_min=time_info->tm_min;
    char time_str[30];
    snprintf(time_str, sizeof(time_str), "Time: %04d-%02d-%02d %02d:%02d  ",
           year, month, day,time_info->tm_hour, time_info->tm_min);
    lcd_show_string(10, 85, (uint8_t*)time_str, LCD_BLUE, LCD_WHITE, 16, 0);


}

/***************************************************************
* 函数名称: update_device_time
* 说    明: 更新设备时间（从时间同步响应中获取）
* 参    数: device_send_time：设备发送时间
*           server_recv_time：服务器接收时间
*           server_send_time：服务器发送时间
* 返 回 值: 无
***************************************************************/
void update_device_time(int64_t device_send_time, int64_t server_recv_time, int64_t server_send_time)
{
    // 计算网络延迟（假设对称）
    int64_t network_delay = (server_recv_time - device_send_time + 
                            (server_send_time - server_recv_time)) / 2;
    
    // 计算当前设备时间 = 服务器发送时间 + 网络延迟
    g_current_time_ms = server_send_time + network_delay;
    
    printf("Updated device time: %lld\n", g_current_time_ms);
}

/***************************************************************
* 函数名称: isl_deal_time_sync_msg
* 说    明: 处理时间同步响应消息
* 参    数: time_sync：时间同步数据指针
* 返 回 值: 无
***************************************************************/
void isl_deal_time_sync_msg(time_sync_data_t *time_sync)
{
    printf("Time Sync Response:\n");
    printf("Device Send Time: %lld\n", time_sync->device_send_time);
    printf("Server Recv Time: %lld\n", time_sync->server_recv_time);
    printf("Server Send Time: %lld\n", time_sync->server_send_time);
    // 更新设备时间
    update_device_time(
        time_sync->device_send_time,
        time_sync->server_recv_time,
        time_sync->server_send_time
    );
    
    // 转换并打印服务器接收时间
    printf("Server Recv Time in datetime format: ");
    timestamp_to_datetime(time_sync->server_recv_time);

    

}

/***************************************************************
* 函数名称: display_medicine_times()
* 说    明: 显示服药时间函数
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void display_medicine_times()
{
    LOS_Msleep(5);
    // 清屏或清空特定区域（根据实际需要）
    //lcd_fill(0, 0, LCD_W, LCD_H, LCD_WHITE); // 清空顶部区域
    // 显示标题
    lcd_show_string(10, 5, (const uint8_t*)"Medicine Times:", LCD_BLUE, LCD_WHITE, 16, 0);
    
    // 显示早、中、晚时间
    char buf[32];
     
    // 早上时间 - 确保截断
    snprintf(buf, sizeof(buf), "Morning: %.5s", g_medicine_schedule1.morning_time);
    lcd_show_string(10, 25, (const uint8_t*)buf, LCD_BLUE, LCD_WHITE, 16, 0);
    LOS_Msleep(5);
    // 中午时间 - 确保截断
    snprintf(buf, sizeof(buf), "Noon:    %.5s", g_medicine_schedule1.noon_time);
    lcd_show_string(10, 45, (const uint8_t*)buf, LCD_BLUE, LCD_WHITE, 16, 0);
    LOS_Msleep(5);
    // 晚上时间 - 确保截断
    snprintf(buf, sizeof(buf), "Evening: %.5s", g_medicine_schedule1.evening_time);
    lcd_show_string(10, 65, (const uint8_t*)buf, LCD_BLUE, LCD_WHITE, 16, 0);
    LOS_Msleep(5);
}

/***************************************************************
* 函数名称: timer1_timeout
* 说    明: 定时器1超时函数
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void timer1_timeout(UINT32 arg)
{
    // 每分钟增加1分钟
    q_min++;
    
    // 处理分钟进位
    if(q_min >= 60)
    {
        q_min = 0;
        q_hour++;
    }
    
    // 处理小时进位
    if(q_hour >= 24)
    {
        q_hour = 0;
        // 每天同步一次时间
        send_event_message();
    }
    
    // 显示当前时间
    char time_str[30];
    snprintf(time_str, sizeof(time_str), "Time: %04d-%02d-%02d %02d:%02d  ",
           q_year, q_mon, q_day, q_hour, q_min);
    lcd_show_string(10, 85, (uint8_t*)time_str, LCD_BLUE, LCD_WHITE, 16, 0);
    // 构造当前时间字符串用于比较
    char current_time_str[6];
    snprintf(current_time_str, sizeof(current_time_str), "%02d:%02d", q_hour, q_min);
    
    // 检查是否匹配服药时间
    if (strncmp(current_time_str, g_medicine_schedule1.morning_time, 5) == 0) 
    {
        printf("\n==== 吃药提醒！ ====\n");
        printf("现在是早上 %s,请服用早上的药物\n", current_time_str);
        lcd_show_string(10, 105, (uint8_t*)"MORNING MEDICINE TIME!", LCD_RED, LCD_WHITE, 16, 0);
    }
    else if (strncmp(current_time_str, g_medicine_schedule1.noon_time, 5) == 0) 
    {
        printf("\n==== 吃药提醒！ ====\n");
        printf("现在是中午 %s,请服用中午的药物\n", current_time_str);
        lcd_show_string(10, 105, (uint8_t*)"NOON MEDICINE TIME!", LCD_RED, LCD_WHITE, 16, 0);
    }
    else if (strncmp(current_time_str, g_medicine_schedule1.evening_time, 5) == 0) 
    {
        printf("\n==== 吃药提醒！ ====\n");
        printf("现在是晚上 %s,请服用晚上的药物\n", current_time_str);
        lcd_show_string(10, 105, (uint8_t*)"EVENING MEDICINE TIME!", LCD_RED, LCD_WHITE, 16, 0);
    }
    else 
    {
        // 不是服药时间时清除提醒信息
        lcd_fill(10, 105, LCD_W, 105+16, LCD_WHITE);
    }
}

/***************************************************************
* 函数名称: medicine_reminder()
* 说    明: 提醒服药函数
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void medicine_reminder()
{
    static unsigned int timer_created = 0; // 静态变量确保只创建一次
    
    if (timer_created) {
        return; // 定时器已创建，直接返回
    }
    
    unsigned int timer_id1;
    unsigned int ret;

    ret = LOS_SwtmrCreate(60000, LOS_SWTMR_MODE_PERIOD, timer1_timeout, &timer_id1, 0);
    if (ret == LOS_OK)
    {
        ret = LOS_SwtmrStart(timer_id1);
        if (ret != LOS_OK)
        { 
            printf("start timer1 fail ret:0x%x\n", ret);
        }
        else
        {
            printf("Timer1 started successfully\n");
            timer_created = 1; // 标记定时器已创建
        }
    }
    else
    {
        printf("create timer1 fail ret:0x%x\n", ret);
    }
}
/***************************************************************
* 函数名称: check()
* 说    明: 检测服药行为函数
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void check();
{

}

/***************************************************************
* 函数名称: iot_cloud_isl_thread
* 说    明: 华为云消息线程
* 参    数: 无
* 返 回 值: 无
***************************************************************/
int iot_cloud_isl_thread()
{
    uint8_t hwaddr[6]  = {0x10, 0xdc, 0xb6, 0x90, 0x00, 0x00};
    isl_msg_t *app_msg = NULL;
    unsigned int addr;
    int ret;


    FlashInit(); 
    VendorSet(VENDOR_ID_MAC,               hwaddr,         6);
    VendorSet(VENDOR_ID_WIFI_ROUTE_SSID,    (unsigned char *)ROUTE_SSID,     sizeof(ROUTE_SSID));
    VendorSet(VENDOR_ID_WIFI_ROUTE_PASSWD,  (unsigned char *)ROUTE_PASSWORD, sizeof(ROUTE_PASSWORD));
    SetWifiModeOn();

    device_info_init(CLIENT_ID, USERNAME, PASSWORD);
    ret = oc_mqtt_init();
    if (ret != LOS_OK)
    {
        printf("oc_mqtt_init fail ret:%d\n", ret);
    }
    send_event_message();
    oc_set_cmd_rsp_cb(isl_cmd_response_callback);   
    printf("Register time sync callback: %p\n", isl_time_sync_callback);
    oc_set_time_sync_cb(isl_time_sync_callback);
    while (1)
    {   
        ret = LOS_QueueRead(m_isl_msg_queue, (void *)&addr, BUFFER_LEN, LOS_WAIT_FOREVER);
        if (ret == LOS_OK)
        { 
            app_msg = (isl_msg_t *)addr;
            printf("Received message from queue: %d\n", app_msg->msg_type);
            switch (app_msg->msg_type)
            {
                    case en_msg_report:
                    printf("Calling isl_deal_report_msg...\n");
                    isl_deal_report_msg(&app_msg->report);
                    break;
                    case en_msg_cmd:
                    printf("Calling isl_deal_cmd_msg...\n");
                    isl_deal_cmd_msg(&app_msg->cmd); 
                    break;
                    case en_msg_time_sync:
                    printf("Calling isl_deal_time_sync_msg...\n");
                    isl_deal_time_sync_msg(&app_msg->time_sync);
                    break;                   
                default:printf("Unknown msg type: %d\n", app_msg->msg_type);
                    break;
            }
            free(app_msg);
            app_msg = NULL;
        }
        else
        {printf("Failed to read message from queue: 0x%x\n", ret);
            LOS_Msleep(100);
        }
    }
}

/***************************************************************
* 函数名称: e53_isl_tread
* 说    明: E53智慧路灯线程
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void e53_isl_tread()
{
    int cover_status = 0;
    isl_msg_t *app_msg = NULL;
    static int last_cover_status ;
    int key=0;
    static char last_morning[16] = {0};
    static char last_noon[16] = {0};
    static char last_evening[16] = {0};
    // 初始化时间同步相关变量
    g_current_time_ms = 0;
    g_last_remind_time_ms = 0;

    e53_isl_init();

     app_msg = malloc(sizeof(isl_msg_t));
     if (app_msg != NULL)
        {
            app_msg->msg_type = en_msg_report;
            app_msg->report.cover_status = (int)cover_status;
            if (LOS_QueueWrite(m_isl_msg_queue, (void *)app_msg, sizeof(isl_msg_t), LOS_WAIT_FOREVER) != LOS_OK)
            {
                printf("%s LOS_QueueWrite fail\n", __func__);
                free(app_msg);
            }
        }
        last_cover_status = cover_status;
        printf("cover_status value is %d\n", cover_status);
        //初试显示
        strcpy(g_medicine_schedule1.morning_time, "08:00");
        strcpy(g_medicine_schedule1.noon_time, "12:00");
        strcpy(g_medicine_schedule1.evening_time, "18:00");
        lcd_show_string(10, 85, "Waiting for time sync...", LCD_BLUE, LCD_WHITE, 16, 0);

        
        medicine_reminder();
    while (1)
    {   
        key=get_key_pressed();
        printf("按键为key%d",key);
        cover_status = e53_isl_read_data();
        //刷新时间
        if ( strcmp(last_morning, g_medicine_schedule1.morning_time) != 0 ||
        strcmp(last_noon, g_medicine_schedule1.noon_time) != 0 ||
        strcmp(last_evening, g_medicine_schedule1.evening_time) != 0) 
    {   
        LOS_Msleep(100);
        display_medicine_times();
        strncpy(last_morning, g_medicine_schedule1.morning_time, sizeof(last_morning));
        LOS_Msleep(5);
        strncpy(last_noon, g_medicine_schedule1.noon_time, sizeof(last_noon));
        LOS_Msleep(5);
        strncpy(last_evening, g_medicine_schedule1.evening_time, sizeof(last_evening));
        LOS_Msleep(5);
 
        
    }
    
        if (cover_status != last_cover_status) 
        {
        if (cover_status == 1) {
        printf("药盒已打开\n");
        } 
        else {
        printf("药盒已关闭\n");
        }
        printf("cover_status value is %d\n", cover_status);
        }
        //发送数据代码
        if (cover_status != last_cover_status) 
        {
        printf("cover_status changed to %d\n", cover_status);
        app_msg = malloc(sizeof(isl_msg_t));
        if (app_msg != NULL)
        {
            app_msg->msg_type = en_msg_report;
            app_msg->report.cover_status = (int)cover_status;
            if (LOS_QueueWrite(m_isl_msg_queue, (void *)app_msg, sizeof(isl_msg_t), LOS_WAIT_FOREVER) != LOS_OK)
            {
                printf("%s LOS_QueueWrite fail\n", __func__);
                free(app_msg);
            }
        }
         }
        last_cover_status = cover_status;

        LOS_Msleep(2000);

    }
}

/***************************************************************
* 函数名称: iot_cloud_isl_example
* 说    明: 华为云智慧路灯例程
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void iot_cloud_isl_example()
{
    unsigned int ret = LOS_OK;
    unsigned int thread_id1;
    unsigned int thread_id2;
    TSK_INIT_PARAM_S task1 = {0};
    TSK_INIT_PARAM_S task2 = {0};

    ret = LOS_QueueCreate("queue", MSG_QUEUE_LENGTH, &m_isl_msg_queue, 0, BUFFER_LEN);
    if (ret != LOS_OK)
    {
        printf("Falied to create Message Queue ret:0x%x\n", ret);
        return;
    }

    task1.pfnTaskEntry = (TSK_ENTRY_FUNC)iot_cloud_isl_thread;
    task1.uwStackSize = 10240;
    task1.pcName = "iot_cloud_isl_thread";
    task1.usTaskPrio = 24;
    ret = LOS_TaskCreate(&thread_id1, &task1);
    if (ret != LOS_OK)
    {
        printf("Falied to create iot_cloud_isl_thread ret:0x%x\n", ret);
        return;
    }

    task2.pfnTaskEntry = (TSK_ENTRY_FUNC)e53_isl_tread;
    task2.uwStackSize = 2048;
    task2.pcName = "e53_isl_tread";
    task2.usTaskPrio = 25;
    ret = LOS_TaskCreate(&thread_id2, &task2);
    if (ret != LOS_OK)
    {
        printf("Falied to create e53_isl_tread ret:0x%x\n", ret);
        return;
    }
}

APP_FEATURE_INIT(iot_cloud_isl_example);