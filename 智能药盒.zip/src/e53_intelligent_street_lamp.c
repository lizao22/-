#include "e53_intelligent_street_lamp.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "los_task.h"
#include "ohos_init.h"
#include "lz_hardware.h"
#include "lcd.h"
#define ISL_I2C0                                    0
#define BH1750_ADDR                                 0x23
#define COVER_SENSOR1_GPIO    GPIO0_PA0
#define COVER_SENSOR2_GPIO    GPIO0_PA1
/* 定义ADC的通道号 */
#define ADC_CHANNEL         5
/* 定义ADC初始化的结构体 */
static DevIo m_adcKey = {
    .isr =   {.gpio = INVALID_GPIO},
    .rst =   {.gpio = INVALID_GPIO},
    .ctrl1 = {.gpio = GPIO0_PC5, .func = MUX_FUNC1, .type = PULL_NONE, .drv = DRIVE_KEEP, .dir = LZGPIO_DIR_IN, .val = LZGPIO_LEVEL_KEEP},
    .ctrl2 = {.gpio = INVALID_GPIO},
};

//static I2cBusIo m_isl_i2c0m2 = {
   // .scl =  {.gpio = GPIO0_PA1, .func = MUX_FUNC3, .type = PULL_NONE, .drv = DRIVE_KEEP, .dir = LZGPIO_DIR_KEEP, .val = LZGPIO_LEVEL_KEEP},
    //.sda =  {.gpio = GPIO0_PA0, .func = MUX_FUNC3, .type = PULL_NONE, .drv = DRIVE_KEEP, .dir = LZGPIO_DIR_KEEP, .val = LZGPIO_LEVEL_KEEP},
    //.id = FUNC_ID_I2C0,
   // .mode = FUNC_MODE_M2,
//};

/***************************************************************
* 函数名称: adc_dev_init
* 说    明: 初始化ADC
* 参    数: 无
* 返 回 值: 0为成功，反之为失败
***************************************************************/
static unsigned int adc_dev_init()
{
    unsigned int ret = 0;
    uint32_t *pGrfSocCon29 = (uint32_t *)(0x41050000U + 0x274U);
    uint32_t ulValue;

    ret = DevIoInit(m_adcKey);
    if (ret != LZ_HARDWARE_SUCCESS)
    {
        printf("%s, %s, %d: ADC Key IO Init fail\n", __FILE__, __func__, __LINE__);
        return __LINE__;
    }
    ret = LzSaradcInit();
    if (ret != LZ_HARDWARE_SUCCESS) {
        printf("%s, %s, %d: ADC Init fail\n", __FILE__, __func__, __LINE__);
        return __LINE__;
    }

    /* 设置saradc的电压信号，选择AVDD */
    ulValue = *pGrfSocCon29;
    ulValue &= ~(0x1 << 4);
    ulValue |= ((0x1 << 4) << 16);
    *pGrfSocCon29 = ulValue;
    
    return 0;
}

/***************************************************************
* 函数名称: adc_get_voltage
* 说    明: 获取ADC电压值
* 参    数: 无
* 返 回 值: 电压值
***************************************************************/
static float adc_get_voltage()
{
    unsigned int ret = LZ_HARDWARE_SUCCESS;
    unsigned int data = 0;
    static unsigned int last_valid_data = 0;
    
    ret = LzSaradcReadValue(ADC_CHANNEL, &data);
    if (ret != LZ_HARDWARE_SUCCESS)
    {
        printf("ADC Read Fail, using last value\n");
        data = last_valid_data;  // 使用上次有效值
    }
    else {
        last_valid_data = data;  // 保存有效值
    }

    // 添加校准系数（根据实际调整）
    const float calibration = 1.02f;
    
    return (float)(data * 3.3 / 1024.0) * calibration;
}

/***************************************************************
* 函数名称: e53_isl_io_init
* 说    明: E53_ISL初始化
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void e53_isl_io_init(void)
{
    LzGpioInit(GPIO0_PA5);
    LzGpioSetDir(GPIO0_PA5, LZGPIO_DIR_OUT);
    
    PinctrlSet(COVER_SENSOR1_GPIO, MUX_FUNC0, PULL_KEEP, DRIVE_LEVEL0);
    LzGpioInit(COVER_SENSOR1_GPIO);
    LzGpioSetDir(COVER_SENSOR1_GPIO, LZGPIO_DIR_IN);
    PinctrlSet(COVER_SENSOR2_GPIO, MUX_FUNC0, PULL_KEEP, DRIVE_LEVEL0);
    LzGpioInit(COVER_SENSOR2_GPIO);
    LzGpioSetDir(COVER_SENSOR2_GPIO, LZGPIO_DIR_IN);
}
/***************************************************************
* 函数名称: e53_isl_init
* 说    明: 总初始化
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void e53_isl_init(void)
{
    e53_isl_io_init();
    adc_dev_init();  // 初始化ADC
    lcd_init();
}

/***************************************************************
* 函数名称: e53_isl_read_data
* 说    明: 读取数据
* 参    数: 无
* 返 回 值: 无
***************************************************************/
int e53_isl_read_data()
{
    int i=0;//判断是哪一个盖的数据
    // 读取两个红外传感器状态（低电平表示有障碍）
    LzGpioValue val1 = LZGPIO_LEVEL_LOW;

    IoTGpioGetInputVal(COVER_SENSOR1_GPIO, &val1);
    //printf("COVER_SENSOR1_GPIO value: %d\n", val1); // 打印电平值
    if(val1 == LZGPIO_LEVEL_HIGH)
    {
        i=1;
    }
    else
    {
        i=0;
    }
    return (i) ;
}
int e53_isl_read_data2()
{
    int i=0;//判断是哪一个盖的数据
    // 读取两个红外传感器状态（低电平表示有障碍）
    LzGpioValue val2 = LZGPIO_LEVEL_LOW;

    IoTGpioGetInputVal(COVER_SENSOR2_GPIO, &val2);
    //printf("COVER_SENSOR1_GPIO value: %d\n", val1); // 打印电平值
    if(val2 == LZGPIO_LEVEL_HIGH)
    {
        i=1;
    }
    else
    {
        i=0;
    }
    return (i) ;
}

/***************************************************************
* 函数名称: buzzer
* 说    明: 蜂鸣器控制
* 参    数: 
*          OFF,关
*          ON,开
* 返 回 值: 无
***************************************************************/
void buzzer(SWITCH_STATUS_ENUM status)
{
    if(status == OFF || status==0)
    {
        /*设置GPIO0_PA5输出高电平关闭蜂鸣器*/
        LzGpioSetVal(GPIO0_PA5, LZGPIO_LEVEL_HIGH);
    }
    if(status == ON ||status==1)
    {
        /*设置GPIO0_PA5输出低电平开启蜂鸣器*/
        LzGpioSetVal(GPIO0_PA5, LZGPIO_LEVEL_LOW);
    }
}

/***************************************************************
* 函数名称: get_key_pressed
* 说    明: 按键扫描
* 参    数: 无
* 返 回 值: 0=无按键, 1=K1, 2=K2, 3=K3, 4=K4
***************************************************************/
int get_key_pressed()
{
    // 多次采样取平均值（提高稳定性）
    const int samples = 8;
    float total_voltage = 0.0f;

        for (int i = 0; i < samples; i++) {
        total_voltage += adc_get_voltage();
        LOS_Msleep(2); // 添加采样间隔
    }

    float voltage = total_voltage / samples;
    
    // 根据实测电压调整参数
    #define NO_KEY_THRESHOLD     3.0f     // 无按键阈值
    #define KEY1_VOLTAGE         0.007f   // K1实测电压
    #define KEY2_VOLTAGE         0.562f   // K2实测电压
    #define KEY3_VOLTAGE         1.081f   // K3实测电压
    #define KEY4_VOLTAGE         1.703f   // K4实测电压
    #define VOLTAGE_TOLERANCE    0.08f    // 容差范围
    
    // 调试信息（每10次调用打印一次）
    static int debug_counter = 0;
    if (debug_counter++ % 10 == 0) {
        printf("ADC Voltage: %.3fV\n", voltage);
    }
    
    // 无按键按下（接近3.363V）
    if (voltage > NO_KEY_THRESHOLD) {
        return 0;
    }
    
    // 精确判断按键（基于实测值）
    if (fabs(voltage - KEY1_VOLTAGE) < VOLTAGE_TOLERANCE) {
        return 1;
    } 
    else if (fabs(voltage - KEY2_VOLTAGE) < VOLTAGE_TOLERANCE) {
        return 2;
    } 
    else if (fabs(voltage - KEY3_VOLTAGE) < VOLTAGE_TOLERANCE) {
        return 3;
    } 
    else if (fabs(voltage - KEY4_VOLTAGE) < VOLTAGE_TOLERANCE) {
        return 4;
    }
    
    // 电压在范围内但未匹配任何按键
    return 0;
}